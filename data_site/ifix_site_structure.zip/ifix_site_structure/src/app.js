// src/app.js - VERSÃO ATUALIZADA COM MÓDULOS ES6
import { DashboardPage } from './pages/dashboard.page.js';
import { CRMPage } from './pages/crm.page.js';
import { OrderServicePage } from './pages/orderservice.page.js';
import { PricePage } from './pages/price.page.js';

const App = (() => {
  const state = {
    currentPage: null,
    currentPageName: null,
    rootElement: null,
    isLoading: false
  };

  // Mapeamento de páginas
  const pages = {
    'dashboard': DashboardPage,
    'crm': CRMPage,
    'orderservice': OrderServicePage,
    'price': PricePage
  };

  // Inicialização do app
  async function init() {
    console.log('🚀 iFix Sistema iniciando...');
    
    // Configurar elemento raiz
    state.rootElement = document.getElementById('app');
    if (!state.rootElement) {
      console.error('❌ Elemento #app não encontrado no DOM');
      return;
    }

    // Configurar navegação
    setupNavigation();
    
    // Carregar página inicial baseada na URL
    const initialPage = getPageFromURL() || 'dashboard';
    await loadPage(initialPage);
    
    console.log('✅ iFix Sistema iniciado com sucesso!');
  }

  // Configurar navegação
  function setupNavigation() {
    // Navegação por links com data-page
    document.addEventListener('click', (e) => {
      const link = e.target.closest('[data-page]');
      if (link) {
        e.preventDefault();
        const pageName = link.dataset.page;
        loadPage(pageName);
      }
    });

    // Navegação por hash na URL
    window.addEventListener('hashchange', () => {
      const pageName = getPageFromURL();
      if (pageName && pageName !== state.currentPageName) {
        loadPage(pageName);
      }
    });

    // Botão voltar/avançar do navegador
    window.addEventListener('popstate', (e) => {
      if (e.state && e.state.page) {
        loadPage(e.state.page);
      }
    });
  }

  // Extrair página da URL
  function getPageFromURL() {
    const hash = window.location.hash.replace('#', '');
    return hash || null;
  }

  // Atualizar URL
  function updateURL(pageName) {
    if (pageName !== 'dashboard') {
      window.location.hash = `#${pageName}`;
    } else {
      window.location.hash = '';
    }
    
    // Atualizar histórico
    window.history.pushState({ page: pageName }, '', window.location.href);
  }

  // Carregar página
  async function loadPage(pageName) {
    try {
      if (state.isLoading || pageName === state.currentPageName) return;
      
      state.isLoading = true;
      
      // Verificar se a página existe
      const PageModule = pages[pageName];
      if (!PageModule) {
        throw new Error(`Página "${pageName}" não encontrada`);
      }

      // Mostrar loading
      showLoading();

      // Desmontar página atual
      if (state.currentPage && state.currentPage.unmount) {
        await state.currentPage.unmount();
      }

      // Atualizar estado
      state.currentPageName = pageName;
      state.currentPage = PageModule;

      // Atualizar URL
      updateURL(pageName);

      // Atualizar menu ativo
      updateActiveMenu(pageName);

      // Montar nova página
      await PageModule.mount({ rootEl: state.rootElement });

      // Esconder loading
      hideLoading();

      console.log(`✅ Página "${pageName}" carregada`);
      
    } catch (error) {
      console.error(`❌ Erro ao carregar página "${pageName}":`, error);
      showError(`Erro ao carregar página: ${error.message}`);
      
      // Fallback para dashboard
      if (pageName !== 'dashboard') {
        setTimeout(() => loadPage('dashboard'), 1000);
      }
    } finally {
      state.isLoading = false;
    }
  }

  // UI Helpers
  function showLoading() {
    const loadingEl = document.getElementById('loading');
    if (loadingEl) {
      loadingEl.style.display = 'flex';
    }
  }

  function hideLoading() {
    const loadingEl = document.getElementById('loading');
    if (loadingEl) {
      loadingEl.style.display = 'none';
    }
  }

  function showError(message) {
    // Criar ou usar sistema de notificação
    const notification = document.createElement('div');
    notification.className = 'notification error';
    notification.innerHTML = `
      <div class="notification-content">
        <i class="fas fa-exclamation-circle"></i>
        <span>${message}</span>
      </div>
      <button class="notification-close">&times;</button>
    `;
    
    notification.querySelector('.notification-close').onclick = () => {
      notification.remove();
    };
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 5000);
  }

  function updateActiveMenu(pageName) {
    // Atualizar classe ativa nos links do menu
    document.querySelectorAll('[data-page]').forEach(link => {
      if (link.dataset.page === pageName) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  // API pública do app
  return {
    init,
    loadPage,
    getCurrentPage: () => state.currentPageName,
    
    // Utilitários para páginas
    showNotification: (message, type = 'info') => {
      const event = new CustomEvent('show-notification', {
        detail: { message, type }
      });
      document.dispatchEvent(event);
    },
    
    openModal: (content) => {
      const event = new CustomEvent('open-modal', {
        detail: { content }
      });
      document.dispatchEvent(event);
    },
    
    closeModal: () => {
      const event = new CustomEvent('close-modal');
      document.dispatchEvent(event);
    }
  };
})();

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

// Exportar para uso global (opcional)
window.App = App;

// Exportar para módulos
export default App;